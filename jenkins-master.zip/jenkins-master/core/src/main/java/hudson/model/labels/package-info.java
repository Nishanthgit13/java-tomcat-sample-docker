/**
 * Boolean expression over labels.
 */
package hudson.model.labels;
